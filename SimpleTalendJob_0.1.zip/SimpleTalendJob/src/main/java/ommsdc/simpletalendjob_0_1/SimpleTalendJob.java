
package ommsdc.simpletalendjob_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.DQTechnical;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 





@SuppressWarnings("unused")

/**
 * Job: SimpleTalendJob Purpose: <br>
 * Description:  <br>
 * @author Rao, T
 * @version 7.0.1.20190226_1146-patch
 * @status 
 */
public class SimpleTalendJob implements TalendJob {
	static {System.setProperty("TalendJob.log", "SimpleTalendJob.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(SimpleTalendJob.class);

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(InputFileLocation != null){
				
					this.setProperty("InputFileLocation", InputFileLocation.toString());
				
			}
			
			if(OutputFileLocation != null){
				
					this.setProperty("OutputFileLocation", OutputFileLocation.toString());
				
			}
			
		}

public String InputFileLocation;
public String getInputFileLocation(){
	return this.InputFileLocation;
}
public String OutputFileLocation;
public String getOutputFileLocation(){
	return this.OutputFileLocation;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "SimpleTalendJob";
	private final String projectName = "OMMSDC";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = java.util.Collections.synchronizedMap(new java.util.HashMap<String, Object>());
		
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}


private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				SimpleTalendJob.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(SimpleTalendJob.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
			}
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tFileInputXML_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWriteJSONField_1_Out_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tWriteJSONField_1_In_error(exception, errorComponent, globalMap);
						
						}
					
			public void tWriteJSONField_1_In_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputXML_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputXML_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWriteJSONField_1_In_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}



	




		


public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
    final static byte[] commonByteArrayLock_OMMSDC_SimpleTalendJob = new byte[0];
    static byte[] commonByteArray_OMMSDC_SimpleTalendJob = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}
				
			    public String Address;

				public String getAddress () {
					return this.Address;
				}
				
			    public String PhNo;

				public String getPhNo () {
					return this.PhNo;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OMMSDC_SimpleTalendJob.length) {
				if(length < 1024 && commonByteArray_OMMSDC_SimpleTalendJob.length == 0) {
   					commonByteArray_OMMSDC_SimpleTalendJob = new byte[1024];
				} else {
   					commonByteArray_OMMSDC_SimpleTalendJob = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OMMSDC_SimpleTalendJob, 0, length);
			strReturn = new String(commonByteArray_OMMSDC_SimpleTalendJob, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OMMSDC_SimpleTalendJob) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Address = readString(dis);
					
					this.PhNo = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Address,dos);
					
					// String
				
						writeString(this.PhNo,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
		sb.append(",Address="+Address);
		sb.append(",PhNo="+PhNo);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(Address == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Address);
            			}
            		
        			sb.append("|");
        		
        				if(PhNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhNo);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_OMMSDC_SimpleTalendJob = new byte[0];
    static byte[] commonByteArray_OMMSDC_SimpleTalendJob = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}
				
			    public String Address;

				public String getAddress () {
					return this.Address;
				}
				
			    public String PhNo;

				public String getPhNo () {
					return this.PhNo;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OMMSDC_SimpleTalendJob.length) {
				if(length < 1024 && commonByteArray_OMMSDC_SimpleTalendJob.length == 0) {
   					commonByteArray_OMMSDC_SimpleTalendJob = new byte[1024];
				} else {
   					commonByteArray_OMMSDC_SimpleTalendJob = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OMMSDC_SimpleTalendJob, 0, length);
			strReturn = new String(commonByteArray_OMMSDC_SimpleTalendJob, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OMMSDC_SimpleTalendJob) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Address = readString(dis);
					
					this.PhNo = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Address,dos);
					
					// String
				
						writeString(this.PhNo,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
		sb.append(",Address="+Address);
		sb.append(",PhNo="+PhNo);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(Address == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Address);
            			}
            		
        			sb.append("|");
        		
        				if(PhNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhNo);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputXML_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
out1Struct out1 = new out1Struct();





	
	/**
	 * [tWriteJSONField_1_Out begin ] start
	 */

	

	
		
		ok_Hash.put("tWriteJSONField_1_Out", false);
		start_Hash.put("tWriteJSONField_1_Out", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tWriteJSONField_1_Out = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_Out - "  + ("Start to work.") );
    	class BytesLimit65535_tWriteJSONField_1_Out{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWriteJSONField_1_Out = new StringBuilder();
            log4jParamters_tWriteJSONField_1_Out.append("Parameters:");
                    log4jParamters_tWriteJSONField_1_Out.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("Name")+", INPUT_COLUMN="+("Name")+"}]");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("REMOVE_HEADER" + " = " + "false");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("CREATE" + " = " + "true");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("CREATE_EMPTY_ELEMENT" + " = " + "true");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("EXPAND_EMPTY_ELM" + " = " + "false");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("OUTPUT_AS_XSD" + " = " + "false");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("COMPACT_FORMAT" + " = " + "true");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("GENERATION_MODE" + " = " + "Dom4j");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                    log4jParamters_tWriteJSONField_1_Out.append("DESTINATION" + " = " + "tWriteJSONField_1");
                log4jParamters_tWriteJSONField_1_Out.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_Out - "  + (log4jParamters_tWriteJSONField_1_Out) );
    		}
    	}
    	
        new BytesLimit65535_tWriteJSONField_1_Out().limitLog4jByte();
//tWriteXMLFieldOut_begin
				int nb_line_tWriteJSONField_1_Out = 0;
				boolean needRoot_tWriteJSONField_1_Out  = true;
				
				String  strCompCache_tWriteJSONField_1_Out= null;		
				
						        java.util.Queue<row1Struct> listGroupby_tWriteJSONField_1_Out = new java.util.concurrent.ConcurrentLinkedQueue<row1Struct>();
							
	
					class ThreadXMLField_tWriteJSONField_1_Out extends Thread {
						
									    java.util.Queue<row1Struct> queue;
									
						java.util.List<java.util.Map<String,String>> flows;
						java.lang.Exception lastException;
						String currentComponent;
						
						ThreadXMLField_tWriteJSONField_1_Out(java.util.Queue q) {
							this.queue = q;
							globalMap.put("queue_tWriteJSONField_1_In", queue);
							lastException = null;
						}
						
						ThreadXMLField_tWriteJSONField_1_Out(java.util.Queue q, java.util.List<java.util.Map<String,String>> l) {
							this.queue = q;
							this.flows = l;
							lastException = null;
							globalMap.put("queue_tWriteJSONField_1_In", queue);
							globalMap.put("flows_tWriteJSONField_1_In", flows);
						}
						
						public java.lang.Exception getLastException() {
							return this.lastException;
						}
						public String getCurrentComponent() {
							return this.currentComponent;
						}
	
						@Override
						public void run() {
							try {
								tWriteJSONField_1_InProcess(globalMap);
							} catch (TalendException te) {
								this.lastException = te.getException();
								this.currentComponent = te.getCurrentComponent();
							}
						}
					}
					
						ThreadXMLField_tWriteJSONField_1_Out txf_tWriteJSONField_1_Out = new ThreadXMLField_tWriteJSONField_1_Out(listGroupby_tWriteJSONField_1_Out);
					
					txf_tWriteJSONField_1_Out.start();
				

java.util.List<java.util.List<String>> groupbyList_tWriteJSONField_1_Out = new java.util.ArrayList<java.util.List<String>>();
java.util.Map<String,String> valueMap_tWriteJSONField_1_Out = new java.util.HashMap<String,String>();


class NestXMLTool_tWriteJSONField_1_Out{
	public void parseAndAdd(org.dom4j.Element nestRoot, String value){
		try {
            org.dom4j.Document doc4Str = org.dom4j.DocumentHelper.parseText("<root>"+ value + "</root>");
    		nestRoot.setContent(doc4Str.getRootElement().content());
    	} catch (java.lang.Exception e) {
    		e.printStackTrace();
    		nestRoot.setText(value);
        }
	}
	
	public void setText(org.dom4j.Element element, String value){
		if (value.startsWith("<![CDATA[") && value.endsWith("]]>")) {
			String text = value.substring(9, value.length()-3);
			element.addCDATA(text);
		}else{
			element.setText(value);
		}
	}
	
	public void replaceDefaultNameSpace(org.dom4j.Element nestRoot){
		if (nestRoot!=null) {
			for (org.dom4j.Element tmp: (java.util.List<org.dom4j.Element>) nestRoot.elements()) {
        		if (("").equals(tmp.getQName().getNamespace().getURI()) && ("").equals(tmp.getQName().getNamespace().getPrefix())){
        			tmp.setQName(org.dom4j.DocumentHelper.createQName(tmp.getName(), nestRoot.getQName().getNamespace()));
	        	}
    	    	replaceDefaultNameSpace(tmp);
       		}
       	}
	}
	
	public void removeEmptyElement(org.dom4j.Element root){
		if (root!=null) {
			for (org.dom4j.Element tmp: (java.util.List<org.dom4j.Element>) root.elements()) {
				removeEmptyElement(tmp);
			}
			if (root.content().size() == 0 
    			&& root.attributes().size() == 0 
    			&& root.declaredNamespaces().size() == 0) {
    			if(root.getParent()!=null){
                	root.getParent().remove(root);
                }
            }
		}
	}
}
NestXMLTool_tWriteJSONField_1_Out nestXMLTool_tWriteJSONField_1_Out = new NestXMLTool_tWriteJSONField_1_Out();

out1Struct  rowStructOutput_tWriteJSONField_1_Out = new out1Struct();
// sort group root element for judgement of group
java.util.List<org.dom4j.Element> groupElementList_tWriteJSONField_1_Out = new java.util.ArrayList<org.dom4j.Element>();
org.dom4j.Element root4Group_tWriteJSONField_1_Out = null;
org.dom4j.Document doc_tWriteJSONField_1_Out  = org.dom4j.DocumentHelper.createDocument();
org.dom4j.io.OutputFormat format_tWriteJSONField_1_Out = org.dom4j.io.OutputFormat.createCompactFormat();
format_tWriteJSONField_1_Out.setNewLineAfterDeclaration(false);
format_tWriteJSONField_1_Out.setTrimText(false);
format_tWriteJSONField_1_Out.setEncoding("ISO-8859-15");
int[] orders_tWriteJSONField_1_Out = new int[1];

 



/**
 * [tWriteJSONField_1_Out begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
    		}
    	}
    	
        new BytesLimit65535_tMap_1().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row2_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out1_tMap_1 = 0;
				
out1Struct out1_tmp = new out1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputXML_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputXML_1", false);
		start_Hash.put("tFileInputXML_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputXML_1";

	
		int tos_count_tFileInputXML_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputXML_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileInputXML_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileInputXML_1 = new StringBuilder();
            log4jParamters_tFileInputXML_1.append("Parameters:");
                    log4jParamters_tFileInputXML_1.append("FILENAME" + " = " + "context.InputFileLocation");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("LOOP_QUERY" + " = " + "\"/Employees/Employee/PersonalInfo\"");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("MAPPING" + " = " + "[{QUERY="+("\"Name\"")+", NODECHECK="+("false")+", SCHEMA_COLUMN="+("Name")+"}, {QUERY="+("\"Address\"")+", NODECHECK="+("false")+", SCHEMA_COLUMN="+("Address")+"}, {QUERY="+("\"PhNo\"")+", NODECHECK="+("false")+", SCHEMA_COLUMN="+("PhNo")+"}]");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("LIMIT" + " = " + "");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("IGNORE_NS" + " = " + "false");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("IGNORE_DTD" + " = " + "false");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("USE_SEPARATOR" + " = " + "false");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("GENERATION_MODE" + " = " + "Dom4j");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("CHECK_DATE" + " = " + "false");
                log4jParamters_tFileInputXML_1.append(" | ");
                    log4jParamters_tFileInputXML_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tFileInputXML_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputXML_1 - "  + (log4jParamters_tFileInputXML_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileInputXML_1().limitLog4jByte();

	

int nb_line_tFileInputXML_1 = 0;

	String os_tFileInputXML_1 = System.getProperty("os.name").toLowerCase();
	boolean isWindows_tFileInputXML_1=false;
	if(os_tFileInputXML_1.indexOf("windows") > -1 || os_tFileInputXML_1.indexOf("nt") > -1){
		isWindows_tFileInputXML_1=true;
	}
class NameSpaceTool_tFileInputXML_1 {

    public java.util.HashMap<String, String> xmlNameSpaceMap = new java.util.HashMap<String, String>();
    
	private java.util.List<String> defualtNSPath = new java.util.ArrayList<String>();

    public void countNSMap(org.dom4j.Element el) {
        for (org.dom4j.Namespace ns : (java.util.List<org.dom4j.Namespace>) el.declaredNamespaces()) {
            if (ns.getPrefix().trim().length() == 0) {
                xmlNameSpaceMap.put("pre"+defualtNSPath.size(), ns.getURI());
                String path = "";
                org.dom4j.Element elTmp = el;
                while (elTmp != null) {
                	if (elTmp.getNamespacePrefix() != null && elTmp.getNamespacePrefix().length() > 0) {
                        path = "/" + elTmp.getNamespacePrefix() + ":" + elTmp.getName() + path;
                    } else {
                        path = "/" + elTmp.getName() + path;
                    }
                    elTmp = elTmp.getParent();
                }
                defualtNSPath.add(path);
            } else {
                xmlNameSpaceMap.put(ns.getPrefix(), ns.getURI());
            }

        }
        for (org.dom4j.Element e : (java.util.List<org.dom4j.Element>) el.elements()) {
            countNSMap(e);
        }
    }
    
    private final org.talend.xpath.XPathUtil util = new  org.talend.xpath.XPathUtil();
    
    {
    	util.setDefaultNSPath(defualtNSPath);
    }
    
	public String addDefaultNSPrefix(String path) {
		return util.addDefaultNSPrefix(path);
	}
	
	public String addDefaultNSPrefix(String relativeXpression, String basePath) {
		return util.addDefaultNSPrefix(relativeXpression,basePath);
	}
    
}

class XML_API_tFileInputXML_1{
	public boolean isDefNull(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null && node instanceof org.dom4j.Element) {
        	org.dom4j.Attribute attri = ((org.dom4j.Element)node).attribute("nil");
        	if(attri != null && ("true").equals(attri.getText())){
            	return true;
            }
        }
        return false;
    }

    public boolean isMissing(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        return node == null ? true : false;
    }

    public boolean isEmpty(org.dom4j.Node node) throws javax.xml.transform.TransformerException {
        if (node != null) {
            return node.getText().length() == 0;
        }
        return false;
    }
}


org.dom4j.io.SAXReader reader_tFileInputXML_1 = new org.dom4j.io.SAXReader();
Object filename_tFileInputXML_1 = null;
try {
	filename_tFileInputXML_1 = context.InputFileLocation;
} catch(java.lang.Exception e) {
	
	
		log.error("tFileInputXML_1 - " + e.getMessage());
	
	System.err.println(e.getMessage());
	
}
if(filename_tFileInputXML_1 != null && filename_tFileInputXML_1 instanceof String && filename_tFileInputXML_1.toString().startsWith("//")){
	if (!isWindows_tFileInputXML_1){
		filename_tFileInputXML_1 = filename_tFileInputXML_1.toString().replaceFirst("//","/");
	}
}

boolean isValidFile_tFileInputXML_1 = true;
org.dom4j.Document doc_tFileInputXML_1 = null;
java.io.Closeable toClose_tFileInputXML_1 = null;
try{
	if(filename_tFileInputXML_1 instanceof java.io.InputStream){
		java.io.InputStream inputStream_tFileInputXML_1 = (java.io.InputStream)filename_tFileInputXML_1;
		toClose_tFileInputXML_1 = inputStream_tFileInputXML_1;
		doc_tFileInputXML_1 = reader_tFileInputXML_1.read(inputStream_tFileInputXML_1);
	}else{
		java.io.Reader unicodeReader_tFileInputXML_1 = new UnicodeReader(new java.io.FileInputStream(String.valueOf(filename_tFileInputXML_1)),"ISO-8859-15");
		toClose_tFileInputXML_1 = unicodeReader_tFileInputXML_1;
		org.xml.sax.InputSource in_tFileInputXML_1= new org.xml.sax.InputSource(unicodeReader_tFileInputXML_1);
		doc_tFileInputXML_1 = reader_tFileInputXML_1.read(in_tFileInputXML_1);
	}
}catch(java.lang.Exception e){
	
		log.error("tFileInputXML_1 - " + e.getMessage());
	
	System.err.println(e.getMessage());
	isValidFile_tFileInputXML_1 = false;
} finally {
	if(toClose_tFileInputXML_1!=null) {
		toClose_tFileInputXML_1.close();
	}
}
if(isValidFile_tFileInputXML_1){
NameSpaceTool_tFileInputXML_1 nsTool_tFileInputXML_1 = new NameSpaceTool_tFileInputXML_1();
nsTool_tFileInputXML_1.countNSMap(doc_tFileInputXML_1.getRootElement());
java.util.HashMap<String,String> xmlNameSpaceMap_tFileInputXML_1 = nsTool_tFileInputXML_1.xmlNameSpaceMap;  

org.dom4j.XPath x_tFileInputXML_1 = doc_tFileInputXML_1.createXPath(nsTool_tFileInputXML_1.addDefaultNSPrefix("/Employees/Employee/PersonalInfo"));  
x_tFileInputXML_1.setNamespaceURIs(xmlNameSpaceMap_tFileInputXML_1); 

java.util.List<org.dom4j.tree.AbstractNode> nodeList_tFileInputXML_1 = (java.util.List<org.dom4j.tree.AbstractNode>)x_tFileInputXML_1.selectNodes(doc_tFileInputXML_1);	
XML_API_tFileInputXML_1 xml_api_tFileInputXML_1 = new XML_API_tFileInputXML_1();
String str_tFileInputXML_1 = "";
org.dom4j.Node node_tFileInputXML_1 = null;

//init all mapping xpaths
java.util.Map<Integer,org.dom4j.XPath> xpaths_tFileInputXML_1=new java.util.HashMap<Integer,org.dom4j.XPath>();
	class XPathUtil_tFileInputXML_1{
	
			   public void initXPaths_0(java.util.Map<Integer,org.dom4j.XPath> xpaths,NameSpaceTool_tFileInputXML_1 nsTool,
			       java.util.HashMap<String,String> xmlNameSpaceMap){
			
	org.dom4j.XPath xpath_0 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("Name","/Employees/Employee/PersonalInfo"));
	xpath_0.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(0,xpath_0);
			
	org.dom4j.XPath xpath_1 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("Address","/Employees/Employee/PersonalInfo"));
	xpath_1.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(1,xpath_1);
			
	org.dom4j.XPath xpath_2 = org.dom4j.DocumentHelper.createXPath(nsTool.addDefaultNSPrefix("PhNo","/Employees/Employee/PersonalInfo"));
	xpath_2.setNamespaceURIs(xmlNameSpaceMap);
	
			xpaths.put(2,xpath_2);
			
	     }
	   
	      public void initXPaths(java.util.Map<Integer,org.dom4j.XPath> xpaths,NameSpaceTool_tFileInputXML_1 nsTool,
			    java.util.HashMap<String,String> xmlNameSpaceMap){
			    
			        initXPaths_0(xpaths,nsTool, xmlNameSpaceMap);
			    
		   }
	}
	XPathUtil_tFileInputXML_1 xPathUtil_tFileInputXML_1 = new XPathUtil_tFileInputXML_1();
	xPathUtil_tFileInputXML_1.initXPaths(xpaths_tFileInputXML_1, nsTool_tFileInputXML_1, xmlNameSpaceMap_tFileInputXML_1);				log.debug("tFileInputXML_1 - Retrieving records from the datasource.");
			
for (org.dom4j.tree.AbstractNode temp_tFileInputXML_1: nodeList_tFileInputXML_1) {
		nb_line_tFileInputXML_1++;
		
	row2 = null;			
	boolean whetherReject_tFileInputXML_1 = false;
	row2 = new row2Struct();
	try{
    Object obj0_tFileInputXML_1 = xpaths_tFileInputXML_1.get(0).evaluate(temp_tFileInputXML_1);
    if(obj0_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj0_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj0_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj0_tFileInputXML_1 instanceof String || obj0_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj0_tFileInputXML_1);
    } else if(obj0_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj0_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}
									if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row2.Name =null;
									}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)){
										row2.Name ="";
									}else if(xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1 )){ 
										row2.Name =null;
									}else{
		row2.Name = str_tFileInputXML_1;
	}
    Object obj1_tFileInputXML_1 = xpaths_tFileInputXML_1.get(1).evaluate(temp_tFileInputXML_1);
    if(obj1_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj1_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj1_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj1_tFileInputXML_1 instanceof String || obj1_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj1_tFileInputXML_1);
    } else if(obj1_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj1_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}
									if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row2.Address =null;
									}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)){
										row2.Address ="";
									}else if(xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1 )){ 
										row2.Address =null;
									}else{
		row2.Address = str_tFileInputXML_1;
	}
    Object obj2_tFileInputXML_1 = xpaths_tFileInputXML_1.get(2).evaluate(temp_tFileInputXML_1);
    if(obj2_tFileInputXML_1 == null) {
    	node_tFileInputXML_1 = null;
    	str_tFileInputXML_1 = "";
    	
    } else if(obj2_tFileInputXML_1 instanceof org.dom4j.Node) {
    	node_tFileInputXML_1 = (org.dom4j.Node)obj2_tFileInputXML_1;
    	str_tFileInputXML_1 = org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
    } else if(obj2_tFileInputXML_1 instanceof String || obj2_tFileInputXML_1 instanceof Number){
    	node_tFileInputXML_1 = temp_tFileInputXML_1;
    	str_tFileInputXML_1 = String.valueOf(obj2_tFileInputXML_1);
    } else if(obj2_tFileInputXML_1 instanceof java.util.List){
    	java.util.List<org.dom4j.Node> nodes_tFileInputXML_1 = (java.util.List<org.dom4j.Node>)obj2_tFileInputXML_1;
    	node_tFileInputXML_1 = nodes_tFileInputXML_1.size()>0 ? nodes_tFileInputXML_1.get(0) : null;
    	str_tFileInputXML_1 = node_tFileInputXML_1==null?"":org.jaxen.function.StringFunction.evaluate(node_tFileInputXML_1,org.jaxen.dom4j.DocumentNavigator.getInstance());
	}
									if(xml_api_tFileInputXML_1.isDefNull(node_tFileInputXML_1)){
											row2.PhNo =null;
									}else if(xml_api_tFileInputXML_1.isEmpty(node_tFileInputXML_1)){
										row2.PhNo ="";
									}else if(xml_api_tFileInputXML_1.isMissing(node_tFileInputXML_1 )){ 
										row2.PhNo =null;
									}else{
		row2.PhNo = str_tFileInputXML_1;
	}
				log.debug("tFileInputXML_1 - Retrieving the record " + (nb_line_tFileInputXML_1) + ".");
			 
			
    } catch (java.lang.Exception e) {
        whetherReject_tFileInputXML_1 = true;
				log.error("tFileInputXML_1 - " + e.getMessage());
			
                System.err.println(e.getMessage());
                row2 = null;
    }
			
			

 



/**
 * [tFileInputXML_1 begin ] stop
 */
	
	/**
	 * [tFileInputXML_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 


	tos_count_tFileInputXML_1++;

/**
 * [tFileInputXML_1 main ] stop
 */
	
	/**
	 * [tFileInputXML_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 process_data_begin ] stop
 */
// Start of branch "row2"
if(row2 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

out1 = null;


// # Output table : 'out1'
count_out1_tMap_1++;

out1_tmp.Name = row2.Name ;
out1_tmp.Address = row2.Address ;
out1_tmp.PhNo = row2.PhNo ;
out1 = out1_tmp;
log.debug("tMap_1 - Outputting the record " + count_out1_tMap_1 + " of the output table 'out1'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "out1"
if(out1 != null) { 



	
	/**
	 * [tWriteJSONField_1_Out main ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";

	

			//out1
			//out1


			
				if(execStat){
					runStat.updateStatOnConnection("out1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out1 - " + (out1==null? "": out1.toLogString()));
    			}
    		

	if(txf_tWriteJSONField_1_Out.getLastException()!=null) {
		currentComponent = txf_tWriteJSONField_1_Out.getCurrentComponent();
		throw txf_tWriteJSONField_1_Out.getLastException();
	}
	nb_line_tWriteJSONField_1_Out++;
				log.debug("tWriteJSONField_1_Out - Processing the record " + nb_line_tWriteJSONField_1_Out + ".");
			
	valueMap_tWriteJSONField_1_Out.clear();
	valueMap_tWriteJSONField_1_Out.put("Name",
	(
		out1.Name != null?
            out1.Name.toString():null
		));
	valueMap_tWriteJSONField_1_Out.put("Address",
	(
		out1.Address != null?
            out1.Address.toString():null
		));
	valueMap_tWriteJSONField_1_Out.put("PhNo",
	(
		out1.PhNo != null?
            out1.PhNo.toString():null
		));
		String strTemp_tWriteJSONField_1_Out = "";		strTemp_tWriteJSONField_1_Out = strTemp_tWriteJSONField_1_Out + valueMap_tWriteJSONField_1_Out.get("Name")
							+ valueMap_tWriteJSONField_1_Out.get("Name").length();
	if(strCompCache_tWriteJSONField_1_Out==null){
		strCompCache_tWriteJSONField_1_Out=strTemp_tWriteJSONField_1_Out;
		
	}else{
		//the data read is different from the data read last time. 
		if(!strCompCache_tWriteJSONField_1_Out.equals(strTemp_tWriteJSONField_1_Out)){	  
    		nestXMLTool_tWriteJSONField_1_Out.replaceDefaultNameSpace(doc_tWriteJSONField_1_Out.getRootElement());			
			java.io.StringWriter strWriter_tWriteJSONField_1_Out = new java.io.StringWriter();	
			org.dom4j.io.XMLWriter output_tWriteJSONField_1_Out = new org.dom4j.io.XMLWriter(strWriter_tWriteJSONField_1_Out, format_tWriteJSONField_1_Out);
			output_tWriteJSONField_1_Out.write(doc_tWriteJSONField_1_Out);
		    output_tWriteJSONField_1_Out.close();
			
				  		  row1Struct row_tWriteJSONField_1_Out = new row1Struct();
						  
					     		row_tWriteJSONField_1_Out.Name = strWriter_tWriteJSONField_1_Out.toString();
					     		listGroupby_tWriteJSONField_1_Out.add(row_tWriteJSONField_1_Out);
					
		    doc_tWriteJSONField_1_Out.clearContent();
			needRoot_tWriteJSONField_1_Out = true;
			for(int i_tWriteJSONField_1_Out=0;i_tWriteJSONField_1_Out<orders_tWriteJSONField_1_Out.length;i_tWriteJSONField_1_Out++){
				orders_tWriteJSONField_1_Out[i_tWriteJSONField_1_Out] = 0;
			}
			
			if(groupbyList_tWriteJSONField_1_Out != null && groupbyList_tWriteJSONField_1_Out.size() >= 0){
				groupbyList_tWriteJSONField_1_Out.clear();
			}
			strCompCache_tWriteJSONField_1_Out=strTemp_tWriteJSONField_1_Out;
		}
	}

	org.dom4j.Element subTreeRootParent_tWriteJSONField_1_Out = null;
	
	// build root xml tree 
	if (needRoot_tWriteJSONField_1_Out) {
		needRoot_tWriteJSONField_1_Out=false;
		org.dom4j.Element root_tWriteJSONField_1_Out = doc_tWriteJSONField_1_Out.addElement("Employees");
		subTreeRootParent_tWriteJSONField_1_Out = root_tWriteJSONField_1_Out;
		org.dom4j.Element root_0_tWriteJSONField_1_Out = root_tWriteJSONField_1_Out.addElement("Employee");
		root4Group_tWriteJSONField_1_Out = subTreeRootParent_tWriteJSONField_1_Out;
	}else{
		subTreeRootParent_tWriteJSONField_1_Out=root4Group_tWriteJSONField_1_Out;
	}
	// build group xml tree 
	// build loop xml tree
		org.dom4j.Element loop_tWriteJSONField_1_Out = org.dom4j.DocumentHelper.createElement("PersonalInfo");
        if(orders_tWriteJSONField_1_Out[0]==0){
        	orders_tWriteJSONField_1_Out[0] = 1;
        }
        if(1 < orders_tWriteJSONField_1_Out.length){
        		orders_tWriteJSONField_1_Out[1] = 0;
        }
        subTreeRootParent_tWriteJSONField_1_Out.elements().add(orders_tWriteJSONField_1_Out[0]++,loop_tWriteJSONField_1_Out);
		org.dom4j.Element loop_0_tWriteJSONField_1_Out = loop_tWriteJSONField_1_Out.addElement("Name");
		if(
		valueMap_tWriteJSONField_1_Out.get("Name")!=null){
			nestXMLTool_tWriteJSONField_1_Out .setText(loop_0_tWriteJSONField_1_Out,
		valueMap_tWriteJSONField_1_Out.get("Name"));
		}
		org.dom4j.Element loop_1_tWriteJSONField_1_Out = loop_tWriteJSONField_1_Out.addElement("Address");
		if(
		valueMap_tWriteJSONField_1_Out.get("Address")!=null){
			nestXMLTool_tWriteJSONField_1_Out .setText(loop_1_tWriteJSONField_1_Out,
		valueMap_tWriteJSONField_1_Out.get("Address"));
		}
		org.dom4j.Element loop_2_tWriteJSONField_1_Out = loop_tWriteJSONField_1_Out.addElement("PhNo");
		if(
		valueMap_tWriteJSONField_1_Out.get("PhNo")!=null){
			nestXMLTool_tWriteJSONField_1_Out .setText(loop_2_tWriteJSONField_1_Out,
		valueMap_tWriteJSONField_1_Out.get("PhNo"));
		}

 


	tos_count_tWriteJSONField_1_Out++;

/**
 * [tWriteJSONField_1_Out main ] stop
 */
	
	/**
	 * [tWriteJSONField_1_Out process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";

	

 



/**
 * [tWriteJSONField_1_Out process_data_begin ] stop
 */
	
	/**
	 * [tWriteJSONField_1_Out process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";

	

 



/**
 * [tWriteJSONField_1_Out process_data_end ] stop
 */

} // End of branch "out1"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row2"




	
	/**
	 * [tFileInputXML_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputXML_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	


}
	}
	globalMap.put("tFileInputXML_1_NB_LINE",nb_line_tFileInputXML_1);
				log.debug("tFileInputXML_1 - Retrieved records count: "+ nb_line_tFileInputXML_1 + " .");
			

	
 
                if(log.isDebugEnabled())
            log.debug("tFileInputXML_1 - "  + ("Done.") );

ok_Hash.put("tFileInputXML_1", true);
end_Hash.put("tFileInputXML_1", System.currentTimeMillis());




/**
 * [tFileInputXML_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out1': " + count_out1_tMap_1 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tWriteJSONField_1_Out end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";

	

if(nb_line_tWriteJSONField_1_Out > 0){  
    nestXMLTool_tWriteJSONField_1_Out.replaceDefaultNameSpace(doc_tWriteJSONField_1_Out.getRootElement());
	java.io.StringWriter strWriter_tWriteJSONField_1_Out = new java.io.StringWriter();
	org.dom4j.io.XMLWriter output_tWriteJSONField_1_Out = new org.dom4j.io.XMLWriter(strWriter_tWriteJSONField_1_Out, format_tWriteJSONField_1_Out);
	output_tWriteJSONField_1_Out.write(doc_tWriteJSONField_1_Out);
    output_tWriteJSONField_1_Out.close();
					row1Struct row_tWriteJSONField_1_Out = new row1Struct();
						  
					     		row_tWriteJSONField_1_Out.Name = strWriter_tWriteJSONField_1_Out.toString();
					     		listGroupby_tWriteJSONField_1_Out.add(row_tWriteJSONField_1_Out);
		    		

}
globalMap.put("tWriteJSONField_1_Out_NB_LINE",nb_line_tWriteJSONField_1_Out);
globalMap.put("tWriteJSONField_1_In_FINISH" + (listGroupby_tWriteJSONField_1_Out==null?"":listGroupby_tWriteJSONField_1_Out.hashCode()), "true");
	
		txf_tWriteJSONField_1_Out.join();
		if(txf_tWriteJSONField_1_Out.getLastException()!=null) {
			currentComponent = txf_tWriteJSONField_1_Out.getCurrentComponent();
			throw txf_tWriteJSONField_1_Out.getLastException();
		}
	
resourceMap.put("finish_tWriteJSONField_1_Out", true);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_Out - "  + ("Done.") );

ok_Hash.put("tWriteJSONField_1_Out", true);
end_Hash.put("tWriteJSONField_1_Out", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk", 0, "ok");
				}



/**
 * [tWriteJSONField_1_Out end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputXML_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputXML_1";

	

 



/**
 * [tFileInputXML_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tWriteJSONField_1_Out finally ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_Out";

	

		java.util.Queue listGroupby_tWriteJSONField_1_Out = (java.util.Queue)globalMap.get("queue_tWriteJSONField_1_In");
		if(resourceMap.get("finish_tWriteJSONField_1_Out") == null){
			globalMap.put("tWriteJSONField_1_In_FINISH_WITH_EXCEPTION" + (listGroupby_tWriteJSONField_1_Out==null?"":listGroupby_tWriteJSONField_1_Out.hashCode()), "true");
		}
	
	if (listGroupby_tWriteJSONField_1_Out != null) {
		globalMap.put("tWriteJSONField_1_In_FINISH" + (listGroupby_tWriteJSONField_1_Out==null?"":listGroupby_tWriteJSONField_1_Out.hashCode()), "true");
	}

 



/**
 * [tWriteJSONField_1_Out finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_OMMSDC_SimpleTalendJob = new byte[0];
    static byte[] commonByteArray_OMMSDC_SimpleTalendJob = new byte[0];

	
			    public String Name;

				public String getName () {
					return this.Name;
				}
				
			    public String Address;

				public String getAddress () {
					return this.Address;
				}
				
			    public String PhNo;

				public String getPhNo () {
					return this.PhNo;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_OMMSDC_SimpleTalendJob.length) {
				if(length < 1024 && commonByteArray_OMMSDC_SimpleTalendJob.length == 0) {
   					commonByteArray_OMMSDC_SimpleTalendJob = new byte[1024];
				} else {
   					commonByteArray_OMMSDC_SimpleTalendJob = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_OMMSDC_SimpleTalendJob, 0, length);
			strReturn = new String(commonByteArray_OMMSDC_SimpleTalendJob, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_OMMSDC_SimpleTalendJob) {

        	try {

        		int length = 0;
		
					this.Name = readString(dis);
					
					this.Address = readString(dis);
					
					this.PhNo = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Name,dos);
					
					// String
				
						writeString(this.Address,dos);
					
					// String
				
						writeString(this.PhNo,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Name="+Name);
		sb.append(",Address="+Address);
		sb.append(",PhNo="+PhNo);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Name);
            			}
            		
        			sb.append("|");
        		
        				if(Address == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Address);
            			}
            		
        			sb.append("|");
        		
        				if(PhNo == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PhNo);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tWriteJSONField_1_InProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWriteJSONField_1_In_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_1", false);
		start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileOutputDelimited_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileOutputDelimited_1 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_1.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_1.append("USESTREAM" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FILENAME" + " = " + "context.OutputFileLocation");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("APPEND" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("INCLUDEHEADER" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("CSV_OPTION" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("CREATE" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("SPLIT" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("DELETE_EMPTYFILE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + (log4jParamters_tFileOutputDelimited_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimited_1().limitLog4jByte();

String fileName_tFileOutputDelimited_1 = "";
    fileName_tFileOutputDelimited_1 = (new java.io.File(context.OutputFileLocation)).getAbsolutePath().replace("\\","/");
    String fullName_tFileOutputDelimited_1 = null;
    String extension_tFileOutputDelimited_1 = null;
    String directory_tFileOutputDelimited_1 = null;
    if((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1.lastIndexOf("/")) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        }
        directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("/"));
    } else {
        if(fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0, fileName_tFileOutputDelimited_1.lastIndexOf("."));
            extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
        } else {
            fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
            extension_tFileOutputDelimited_1 = "";
        }
        directory_tFileOutputDelimited_1 = "";
    }
    boolean isFileGenerated_tFileOutputDelimited_1 = true;
    java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
    globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
        if(filetFileOutputDelimited_1.exists()){
            isFileGenerated_tFileOutputDelimited_1 = false;
        }
            int nb_line_tFileOutputDelimited_1 = 0;
            int splitedFileNo_tFileOutputDelimited_1 = 0;
            int currentRow_tFileOutputDelimited_1 = 0;

            final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */";"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */;

            final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:ROWSEPARATOR */"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */;

                    //create directory only if not exists
                    if(directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
                        java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
                        if(!dir_tFileOutputDelimited_1.exists()) {
                                log.info("tFileOutputDelimited_1 - Creating directory '" + dir_tFileOutputDelimited_1.getCanonicalPath() +"'.");
                            dir_tFileOutputDelimited_1.mkdirs();
                                log.info("tFileOutputDelimited_1 - The directory '"+ dir_tFileOutputDelimited_1.getCanonicalPath() + "' has been created successfully.");
                        }
                    }

                        //routines.system.Row
                        java.io.Writer outtFileOutputDelimited_1 = null;

                        outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
                        new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, true),"ISO-8859-15"));


        resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

 



/**
 * [tFileOutputDelimited_1 begin ] stop
 */



	
	/**
	 * [tWriteJSONField_1_In begin ] start
	 */

	

	
		
		ok_Hash.put("tWriteJSONField_1_In", false);
		start_Hash.put("tWriteJSONField_1_In", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";

	
		int tos_count_tWriteJSONField_1_In = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_In - "  + ("Start to work.") );
    	class BytesLimit65535_tWriteJSONField_1_In{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWriteJSONField_1_In = new StringBuilder();
            log4jParamters_tWriteJSONField_1_In.append("Parameters:");
                    log4jParamters_tWriteJSONField_1_In.append("JSONFIELD" + " = " + "Name");
                log4jParamters_tWriteJSONField_1_In.append(" | ");
                    log4jParamters_tWriteJSONField_1_In.append("DESTINATION" + " = " + "tWriteJSONField_1");
                log4jParamters_tWriteJSONField_1_In.append(" | ");
                    log4jParamters_tWriteJSONField_1_In.append("REMOVE_ROOT" + " = " + "false");
                log4jParamters_tWriteJSONField_1_In.append(" | ");
                    log4jParamters_tWriteJSONField_1_In.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("Name")+", INPUT_COLUMN="+("Name")+"}]");
                log4jParamters_tWriteJSONField_1_In.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_In - "  + (log4jParamters_tWriteJSONField_1_In) );
    		}
    	}
    	
        new BytesLimit65535_tWriteJSONField_1_In().limitLog4jByte();

				int nb_line_tWriteJSONField_1_In = 0;
				net.sf.json.xml.XMLSerializer xmlSerializer_tWriteJSONField_1_In = new net.sf.json.xml.XMLSerializer(); 
			    xmlSerializer_tWriteJSONField_1_In.clearNamespaces();
			    xmlSerializer_tWriteJSONField_1_In.setSkipNamespaces(true);
			    xmlSerializer_tWriteJSONField_1_In.setForceTopLevelObject(true);
				
					   java.util.Queue<row1Struct> queue_tWriteJSONField_1_In = (java.util.Queue<row1Struct>) globalMap.get("queue_tWriteJSONField_1_In");
					
				String readFinishMarkWithPipeId_tWriteJSONField_1_In = "tWriteJSONField_1_In_FINISH"+(queue_tWriteJSONField_1_In==null?"":queue_tWriteJSONField_1_In.hashCode());
				String str_tWriteJSONField_1_In = null;
				
				while(!globalMap.containsKey(readFinishMarkWithPipeId_tWriteJSONField_1_In) || !queue_tWriteJSONField_1_In.isEmpty()) {
					if (!queue_tWriteJSONField_1_In.isEmpty()) {
			

 



/**
 * [tWriteJSONField_1_In begin ] stop
 */
	
	/**
	 * [tWriteJSONField_1_In main ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";

	

                    row1Struct result_tWriteJSONField_1_In = queue_tWriteJSONField_1_In.poll();
                    str_tWriteJSONField_1_In = result_tWriteJSONField_1_In.Name;
                                row1.Name = result_tWriteJSONField_1_In.Name;
        //Convert XML to JSON
        net.sf.json.JSON json_tWriteJSONField_1_In = xmlSerializer_tWriteJSONField_1_In.read(str_tWriteJSONField_1_In);
        row1.Name = json_tWriteJSONField_1_In.toString();
    
        nb_line_tWriteJSONField_1_In++;

 


	tos_count_tWriteJSONField_1_In++;

/**
 * [tWriteJSONField_1_In main ] stop
 */
	
	/**
	 * [tWriteJSONField_1_In process_data_begin ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";

	

 



/**
 * [tWriteJSONField_1_In process_data_begin ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		


                    StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
                            if(row1.Name != null) {
                        sb_tFileOutputDelimited_1.append(
                            row1.Name
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(row1.Address != null) {
                        sb_tFileOutputDelimited_1.append(
                            row1.Address
                        );
                            }
                            sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
                            if(row1.PhNo != null) {
                        sb_tFileOutputDelimited_1.append(
                            row1.PhNo
                        );
                            }
                    sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);


                    nb_line_tFileOutputDelimited_1++;
                    resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

                        outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());
                        log.debug("tFileOutputDelimited_1 - Writing the record " + nb_line_tFileOutputDelimited_1 + ".");




 


	tos_count_tFileOutputDelimited_1++;

/**
 * [tFileOutputDelimited_1 main ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_begin ] stop
 */
	
	/**
	 * [tFileOutputDelimited_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

 



/**
 * [tFileOutputDelimited_1 process_data_end ] stop
 */



	
	/**
	 * [tWriteJSONField_1_In process_data_end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";

	

 



/**
 * [tWriteJSONField_1_In process_data_end ] stop
 */
	
	/**
	 * [tWriteJSONField_1_In end ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";

	

					}
				}
				
					String readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In = "tWriteJSONField_1_In_FINISH_WITH_EXCEPTION"+(queue_tWriteJSONField_1_In==null?"":queue_tWriteJSONField_1_In.hashCode());
					if(globalMap.containsKey(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In)){
						if(!(globalMap instanceof java.util.concurrent.ConcurrentHashMap)) {
							globalMap.put(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In, null);// syn
						}
						globalMap.remove(readFinishWithExceptionMarkWithPipeId_tWriteJSONField_1_In);
						return;
					}
					globalMap.remove("queue_tWriteJSONField_1_In");
    			
				if(!(globalMap instanceof java.util.concurrent.ConcurrentHashMap)) {
					globalMap.put(readFinishMarkWithPipeId_tWriteJSONField_1_In,null);//syn
				}
				globalMap.remove(readFinishMarkWithPipeId_tWriteJSONField_1_In);
			
globalMap.put("tWriteJSONField_1_NB_LINE",nb_line_tWriteJSONField_1_In);
				log.debug("tWriteJSONField_1_In - Processed records count: " + nb_line_tWriteJSONField_1_In + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tWriteJSONField_1_In - "  + ("Done.") );

ok_Hash.put("tWriteJSONField_1_In", true);
end_Hash.put("tWriteJSONField_1_In", System.currentTimeMillis());




/**
 * [tWriteJSONField_1_In end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	



		
			
					if(outtFileOutputDelimited_1!=null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}
				
				globalMap.put("tFileOutputDelimited_1_NB_LINE",nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME",fileName_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_1", true);
	
				log.debug("tFileOutputDelimited_1 - Written records count: " + nb_line_tFileOutputDelimited_1 + " .");
			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + ("Done.") );

ok_Hash.put("tFileOutputDelimited_1", true);
end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());




/**
 * [tFileOutputDelimited_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWriteJSONField_1_In finally ] start
	 */

	

	
	
		currentVirtualComponent = "tWriteJSONField_1";
	
	currentComponent="tWriteJSONField_1_In";

	

 



/**
 * [tWriteJSONField_1_In finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_tFileOutputDelimited_1") == null){ 
			
				
						java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer)resourceMap.get("out_tFileOutputDelimited_1");
						if(outtFileOutputDelimited_1!=null) {
							outtFileOutputDelimited_1.flush();
							outtFileOutputDelimited_1.close();
						}
					
				
			
		}
	

 



/**
 * [tFileOutputDelimited_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWriteJSONField_1_In_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final SimpleTalendJob SimpleTalendJobClass = new SimpleTalendJob();

        int exitCode = SimpleTalendJobClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'SimpleTalendJob' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'SimpleTalendJob' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = SimpleTalendJob.class.getClassLoader().getResourceAsStream("ommsdc/simpletalendjob_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = SimpleTalendJob.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                //defaultProps is in order to keep the original context value
                defaultProps.load(inContext);
                inContext.close();
                context = new ContextProperties(defaultProps);
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
				    context.setContextType("InputFileLocation", "id_String");
				
                context.InputFileLocation=(String) context.getProperty("InputFileLocation");
				    context.setContextType("OutputFileLocation", "id_String");
				
                context.OutputFileLocation=(String) context.getProperty("OutputFileLocation");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("InputFileLocation")) {
                context.InputFileLocation = (String) parentContextMap.get("InputFileLocation");
            }if (parentContextMap.containsKey("OutputFileLocation")) {
                context.OutputFileLocation = (String) parentContextMap.get("OutputFileLocation");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob




this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tFileInputXML_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tFileInputXML_1) {
globalMap.put("tFileInputXML_1_SUBPROCESS_STATE", -1);

e_tFileInputXML_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob




        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : SimpleTalendJob");
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {


    }














    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     95428 characters generated by Talend Real-time Big Data Platform 
 *     on the October 8, 2020 4:30:25 PM IST
 ************************************************************************************************/